<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('activationCode', function (Blueprint $table) {
            $table->id();
            $table->integer('activationCode');
            $table->dateTime('created_at', $precision=0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('activationCode', function (Blueprint $table) {
            Schema::dropIfExists('activationCode');
        });
    }
};
