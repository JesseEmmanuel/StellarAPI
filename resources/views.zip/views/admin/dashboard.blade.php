@extends('admin.templates.layout')

@section('content')
<div class="row">
    <h1>Dashboard</h1>
</div>
@endsection
